package lab.pkg5.constants;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author ahmadyasserhamad
 */
public interface FileNames {
    
    String TRAINER_FILENAME = "Trainers.txt";
    String MEMBER_FILENAME = "Members.txt";
    String CLASS_FILENAME = "Classes.txt";
    String REGISTRATION_FILENAME = "Registration.txt";
    
}
