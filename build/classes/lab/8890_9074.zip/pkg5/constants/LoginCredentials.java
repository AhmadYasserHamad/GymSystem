package lab.pkg5.constants;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
/**
 *
 * @author ahmadyasserhamad
 */
public interface LoginCredentials {

    String ADMIN_USERNAME = "admin";
    String ADMIN_PASSWORD = "12345";
    String TRAINER_USERNAME = "trainer";
    String TRAINER_PASSWORD = "56789";
}
