/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkg5.frontend;

/**
 *
 * @author ahmadyasserhamad
 */
public class Project {
    
    public static void main(String[] args){
        new InitialChoice().setVisible(true);
    }
    
}
